#include "Heap.h"
#include"Task.h"
#include<iostream>
#include<bits/stdc++.h>
#include<string>
using namespace std;
template <class T>
Heap<T>::Heap()
{
}
template <class T>
Heap<T>::Heap(T* heapElements,int size)
{
  //task_array=heapElements;
 // Max_size=size;

}
template<class T>
void Heap<T>::heapify(T arr[],int n,int i)
 {
   int l=2*i+1;
   int r=2*i+2;
   int max=i;
   if(l<n&&arr[l].get_priority()>arr[max].get_priority())
     max=l;
   if(r<n&&arr[r].get_priority()>arr[max].get_priority())
     max=r;
   if(max != i)
    {
        swap(arr[i],arr[max]);
        heapify(arr,n,max);
    }
 }
template<class T>
void Heap<T>::buildHeap(T arr[],int n)
{
	for (int i = n/2-1; i>= 0; i--)
		heapify(arr, n, i);
}
template<class T>
void Heap<T>::buildHeap()
{
    buildHeap(task_array,size+1);
}


template<class T>
void Heap<T>::heapSort(T arr[], int n)
{
    Heap<Task>heap;
	buildHeap(arr, n);
	for (int i = n-1; i >=0; i--)
	{
		swap(arr[0], arr[i]);
		heapify(arr, i, 0);
	}

}

template<class T>
void Heap<T>::heapSort()
{
    heapSort(task_array,size+1);
}

template<class T>
void Heap<T>::add(T task)
{

     int pr=task.get_priority();
     string name=task.get_name();
     size++;
     task_array[size].set_name(name);
     task_array[size].set_priority(pr);

}


template<class T>
void Heap<T>::print(T arr[], int n)
{
	for (int i = 0; i < n+1; i++)
	{
		cout << arr[i].get_name() << " ";
		cout << arr[i].get_priority() << " ";
		cout << endl;
	}
	cout << endl;

}
template<class T>
void Heap<T>::print()
{
     print(task_array,size);
}

template<class T>
void Heap<T>::search (string taskName)
{
    search(task_array, size+1,taskName);
}

template<class T>
void Heap<T>::search(T arr[],int n,string taskName)
{
    for(int i=0;i<=n;i++)
    {
        if(taskName==arr[i].get_name())
        {
            cout<<"WE FOUND IT"<<endl;
            cout<<"THE NAME OF THE TASK IS :"<<arr[i].get_name()<<"  ";
            cout<<"IT'S Priority is :"<<arr[i].get_priority()<<endl;
            return;
        }
    }
    cout<<"NOT FOUND"<<endl;
}


template<class T>
void Heap<T>::removeRoot(T arr[], int n)
{
  string top_Task=arr[0].get_name();
  cout<<"The top is : "<<top_Task<<endl;
  swap(arr[0],arr[n-1]);
  size=size-1;
}

template<class T>
void Heap<T>::removeRoot()
{
    removeRoot(task_array,size+1);
}

