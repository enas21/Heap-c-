#include "ass.h"

ass::ass()
{
    //ctor
}

ass::~ass()
{
    //dtor
}
