#include "Task.h"
#include <iostream>
#include<string>
using namespace std;
Task::Task()
{


}

Task::~Task()
{
    //dtor
}

void Task::set_name(string name)
{
    Name=name;
}

void Task::set_priority(int priority)
{
    Priority=priority;
}

string Task::get_name()
{
    return Name;
}

int Task::get_priority()
{
    return Priority;
}




