#ifndef ASS_H
#define ASS_H


class ass
{
    public:
        ass();
        virtual ~ass();

    protected:

    private:
};

#endif // ASS_H
