#ifndef HEAP_H
#define HEAP_H
#include<iostream>
#include<bits/stdc++.h>
#include<string>
#include "Task.h"
using namespace std;
template <class T>
class Heap
{
    private:
        T* heapElements;
        int size = -1;
    public:
        Task task_array[1000];
        Heap ();
        Heap (T* heapElements, int size);
        void heapify(T task_array[],int Max_size,int i);
        void add(T elem);
        void removeRoot(T arr[], int n);
        void removeRoot();
        void search (string taskName);
        void search(T arr[],int n,string taskName);
        void buildHeap(T arr[],int n);
        void buildHeap();
        void heapSort(T arr[], int n);
        void heapSort();
        void print(T arr[], int n);
        void print();




    protected:


};

#endif // HEAP_H
